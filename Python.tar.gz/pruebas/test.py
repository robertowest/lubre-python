class prueba:
        print('hola')

if __name__ == '__main__':
        print('adios')
